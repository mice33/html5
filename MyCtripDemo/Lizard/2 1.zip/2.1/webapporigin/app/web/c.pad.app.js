define(['cCoreInherit', 'cWebApp', 'cPadExtend'], function (cCoreInherit, APP, cPadExtend) {  
  return cCoreInherit.Class(APP, cPadExtend);
});