## .NET
[测试方法](http://conf.ctripcorp.com/pages/viewpage.action?pageId=48859121)
这个测试方法不适用于本地

* http://logging.sh.ctripcorp.com/
* 9222

## Node.js
1. cd node
2. edit var/config.js for you project
  
3. start app        
```
  production: node app  
  development: grunt app --debug
```

4. view http://127.0.0.1:3000/html5/demo


## 线上node版seo程序（现在使用这个在本地测试）

1. cd node
2. edit var/config.js for you project
  
3. start app        
```
  production: node app  
  development: grunt app --debug
```