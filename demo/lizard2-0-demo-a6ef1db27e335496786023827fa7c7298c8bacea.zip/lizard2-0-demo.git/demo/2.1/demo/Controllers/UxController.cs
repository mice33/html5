﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace demo.Controllers
{
    public class UxController : Controller
    {
        //
        // GET: /Ux/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Scroll()
        {
            return View();
        }

    }
}
