﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace demo.Controllers
{
    public class HybridController : Controller
    {
        //
        // GET: /Hybrid/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddressList()
        {
            return View();
        }
        public ActionResult H5ToHybrid()
        {
            return View();
        }
        public ActionResult SkipChannel()
        {
            return View();
        }
    }
}
