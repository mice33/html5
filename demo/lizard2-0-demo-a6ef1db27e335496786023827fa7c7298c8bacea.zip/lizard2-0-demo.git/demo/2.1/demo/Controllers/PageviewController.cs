﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace demo.Controllers
{
    public class PageviewController : Controller
    {
        //
        // GET: /Page/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Datas()
        {
            return View();
        }

        public ActionResult Dollar()
        {
            return View();
        }

        public ActionResult DollarElement()
        {
            return View();
        }

        public ActionResult Header()
        {
            return View();
        }

        public ActionResult Referrer()
        {
            return View();
        }

        public ActionResult RestoreScrollPos()
        {
            return View();
        }

        public ActionResult ScrollPos()
        {
            return View();
        }

        public ActionResult ScrollZero()
        {
            return View();
        }
        public ActionResult ShowFake()
        {
            return View();
        }
        public ActionResult ShowConfirm()
        {
            return View();
        }
        public ActionResult HideConfirm()
        {
            return View();
        }
        public ActionResult ShowLoading()
        {
            return View();
        }
        public ActionResult HideLoading()
        {
            return View();
        }
        public ActionResult ShowMessage()
        {
            return View();
        }
        public ActionResult HideMessage()
        {
            return View();
        }
        public ActionResult ShowToast()
        {
            return View();
        }
        public ActionResult HideToast()
        {
            return View();
        }
        public ActionResult PageId()
        {
            return View();
        }
        public ActionResult HPageId()
        {
            return View();
        }
        public ActionResult On()
        {
            return View();
        }
        public ActionResult Off()
        {
            return View();
        }
        public ActionResult Trigger()
        {
            return View();
        }
    }
}
