﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace demo.Controllers
{
    public class UiController : Controller
    {
        //
        // GET: /Ui/

        public ActionResult Index()
        {
            return View();
        }

        //GET: /Ui/
        public ActionResult Header()
        {
          return View();
        }

        //GET: /Ui/
        public ActionResult New_header()
        {
          return View();
        }

        public ActionResult header_sidebar()
        {
          return View();
        }
        public ActionResult header_select()
        {
          return View();
        }

        public ActionResult header_tabs()
        {
          return View();
        }

        public ActionResult header_share()
        {
          return View();
        }

        public ActionResult alert()
        {
          return View();
        }

        public ActionResult toast()
        {
          return View();
        }

        public ActionResult loading()
        {
          return View();
        }

        public ActionResult bubble_layer()
        {
          return View();
        }

        public ActionResult layer_list()
        {
          return View();
        }

        public ActionResult user_defined_layer()
        {
          return View();
        }

        public ActionResult identity()
        {
          return View();
        }

        public ActionResult image_slider()
        {
          return View();
        }

        public ActionResult num()
        {
          return View();
        }

        public ActionResult select()
        {
          return View();
        }

        public ActionResult switch1()
        {
          return View();
        }

        public ActionResult tab()
        {
          return View();
        }

        public ActionResult calendar()
        {
          return View();
        }

        public ActionResult slider()
        {
          return View();
        }

        public ActionResult scrolllayer()
        {
          return View();
        }

        public ActionResult scroll()
        {
          return View();
        }

        public ActionResult scroll_list()
        {
          return View();
        }
        public ActionResult group_select()
        {
          return View();
        }

        public ActionResult header_template()
        {
          return View();
        }
    }
}
